import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, Plus, X, Minus, Square, Copy, Check, Download, 
  FolderOpen, Save, Search, RefreshCw, Clock, Moon, Sun, 
  Monitor, ExternalLink, ArrowLeft, AlignLeft, Info
} from 'lucide-react';

interface Tab {
  id: string;
  name: string;
  content: string;
  isModified: boolean;
  fileHandle?: any; // FileSystemFileHandle if available
  filePath?: string;
}

interface WindowsNotepadProps {
  onBack: () => void;
}

export default function WindowsNotepad({ onBack }: WindowsNotepadProps) {
  const [tabs, setTabs] = useState<Tab[]>(() => {
    const saved = localStorage.getItem('caet_notepad_tabs');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((t: any) => ({ ...t, fileHandle: undefined }));
        }
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: '1',
        name: '제목 없음.txt',
        content: `캐트 게이밍 플랫폼 - 윈도우 메모장 (Windows Notepad)\n==================================================\n\n[실제 윈도우 연동 지원 기능]\n1. Ctrl + S : 윈도우 PC에 .txt 파일로 즉시 저장\n2. Ctrl + O : 윈도우 파일 탐색기에서 내 PC 파일 직접 열기\n3. 드래그 앤 드롭 : 윈도우 탐색기나 바탕화면의 .txt 파일을 여기로 끌어다 놓으세요!\n4. F5 키 : 윈도우 메모장 고유 기능인 현재 날짜/시간 스탬프 삽입\n5. 상단 [실제 윈도우 메모장 실행] 버튼 : 작성한 텍스트를 실제 PC의 notepad.exe로 실행\n\n이곳에 자유롭게 메모를 작성해보세요!`,
        isModified: false
      }
    ];
  });

  const [activeTabId, setActiveTabId] = useState<string>(() => tabs[0]?.id || '1');
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [wordWrap, setWordWrap] = useState<boolean>(true);
  const [fontSize, setFontSize] = useState<number>(14);
  const [fontFamily, setFontFamily] = useState<'malgun' | 'consolas' | 'sans'>('malgun');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [isMaximized, setIsMaximized] = useState<boolean>(false);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [showFindBar, setShowFindBar] = useState<boolean>(false);
  const [findQuery, setFindQuery] = useState<string>('');
  const [replaceQuery, setReplaceQuery] = useState<string>('');
  const [showWinModal, setShowWinModal] = useState<boolean>(false);
  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];
  // Auto-launch real Windows notepad and auto-focus when entering
  useEffect(() => {
    try {
      const a = document.createElement('a');
      a.href = 'ms-notepad:';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (e) {
      console.warn('Auto protocol trigger', e);
    }
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  // One-click batch launcher for notepad.exe
  const downloadBatchLauncher = () => {
    const batContent = `@echo off\r\nstart "" notepad.exe\r\nexit\r\n`;
    const blob = new Blob([batContent], { type: 'application/x-bat' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = '메모장_실행.bat';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    notify('원클릭 실행기(메모장_실행.bat) 다운로드 완료! 클릭 시 실제 메모장이 즉시 켜집니다.');
  };


  // Save to localStorage
  useEffect(() => {
    try {
      const serializable = tabs.map(({ id, name, content, isModified }) => ({
        id, name, content, isModified
      }));
      localStorage.setItem('caet_notepad_tabs', JSON.stringify(serializable));
    } catch (e) {
      console.error(e);
    }
  }, [tabs]);

  // Show status notification
  const notify = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(''), 3500);
  };

  // Cursor position calculation
  const updateCursorPosition = () => {
    if (!textareaRef.current) return;
    const text = textareaRef.current.value;
    const selStart = textareaRef.current.selectionStart;
    const lines = text.substring(0, selStart).split('\n');
    const currentLine = lines.length;
    const currentCol = lines[lines.length - 1].length + 1;
    setCursorPos({ line: currentLine, col: currentCol });
  };

  // Text change handler
  const handleContentChange = (newContent: string) => {
    setTabs(prev => prev.map(tab => {
      if (tab.id === activeTabId) {
        return { ...tab, content: newContent, isModified: true };
      }
      return tab;
    }));
  };

  // Insert date/time (F5)
  const insertDateTime = () => {
    if (!textareaRef.current) return;
    const now = new Date();
    const formatted = `${now.toLocaleTimeString('ko-KR', { hour: 'numeric', minute: '2-digit', hour12: true })} ${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    
    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const newText = text.substring(0, start) + formatted + text.substring(end);
    
    handleContentChange(newText);
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + formatted.length;
      updateCursorPosition();
    }, 10);
    notify(`현재 날짜/시간 삽입됨 (${formatted})`);
  };

  // New Tab
  const handleNewTab = () => {
    const newId = Date.now().toString();
    const newName = `제목 없음 ${tabs.length + 1}.txt`;
    const newTab: Tab = {
      id: newId,
      name: newName,
      content: '',
      isModified: false
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
    notify('새 메모 탭이 생성되었습니다.');
  };

  // Close Tab
  const handleCloseTab = (e: React.MouseEvent, idToClose: string) => {
    e.stopPropagation();
    if (tabs.length === 1) {
      // Don't close last tab, just reset it
      setTabs([{
        id: Date.now().toString(),
        name: '제목 없음.txt',
        content: '',
        isModified: false
      }]);
      return;
    }

    const filtered = tabs.filter(t => t.id !== idToClose);
    setTabs(filtered);
    if (activeTabId === idToClose) {
      setActiveTabId(filtered[filtered.length - 1].id);
    }
  };

  // Real Windows File Open (File System Access API or File input)
  const handleOpenFile = async () => {
    setActiveMenu(null);
    if ('showOpenFilePicker' in window) {
      try {
        const [fileHandle] = await (window as any).showOpenFilePicker({
          types: [
            {
              description: '텍스트 문서 (*.txt;*.log;*.md;*.json)',
              accept: {
                'text/plain': ['.txt', '.log', '.ini', '.md', '.json', '.csv', '.bat']
              }
            }
          ],
          multiple: false
        });
        const file = await fileHandle.getFile();
        const text = await file.text();
        
        const newTab: Tab = {
          id: Date.now().toString(),
          name: file.name,
          content: text,
          isModified: false,
          fileHandle: fileHandle,
          filePath: file.name
        };
        setTabs(prev => [...prev, newTab]);
        setActiveTabId(newTab.id);
        notify(`윈도우 파일 열기 성공: ${file.name}`);
        return;
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.warn('showOpenFilePicker failed, falling back:', err);
        } else {
          return;
        }
      }
    }

    // Fallback file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const newTab: Tab = {
        id: Date.now().toString(),
        name: file.name,
        content: text,
        isModified: false
      };
      setTabs(prev => [...prev, newTab]);
      setActiveTabId(newTab.id);
      notify(`윈도우 파일 로드 완료: ${file.name}`);
    };
    reader.readAsText(file);
  };

  // Real Windows File Save (File System Access API or Download)
  const handleSaveFile = async (saveAs: boolean = false) => {
    setActiveMenu(null);
    if (!activeTab) return;

    // Direct save with FileHandle
    if (!saveAs && activeTab.fileHandle && 'createWritable' in activeTab.fileHandle) {
      try {
        const writable = await activeTab.fileHandle.createWritable();
        await writable.write(activeTab.content);
        await writable.close();
        setTabs(prev => prev.map(t => t.id === activeTab.id ? { ...t, isModified: false } : t));
        notify(`PC 윈도우 파일에 직접 저장됨: ${activeTab.name}`);
        return;
      } catch (err) {
        console.warn('Direct file handle write failed:', err);
      }
    }

    // Show save file picker if supported
    if ('showSaveFilePicker' in window) {
      try {
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: activeTab.name.endsWith('.txt') ? activeTab.name : `${activeTab.name}.txt`,
          types: [
            {
              description: '텍스트 문서 (*.txt)',
              accept: { 'text/plain': ['.txt'] }
            }
          ]
        });
        const writable = await handle.createWritable();
        await writable.write(activeTab.content);
        await writable.close();
        const file = await handle.getFile();
        setTabs(prev => prev.map(t => t.id === activeTab.id ? { 
          ...t, 
          name: file.name, 
          isModified: false,
          fileHandle: handle 
        } : t));
        notify(`윈도우 PC에 파일 저장 완료: ${file.name}`);
        return;
      } catch (err: any) {
        if (err.name === 'AbortError') return;
        console.warn('showSaveFilePicker failed, fallback to download:', err);
      }
    }

    // Standard Download fallback
    const blob = new Blob([activeTab.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeTab.name.endsWith('.txt') ? activeTab.name : `${activeTab.name}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setTabs(prev => prev.map(t => t.id === activeTab.id ? { ...t, isModified: false } : t));
    notify(`윈도우 다운로드 폴더로 파일 저장됨 (${link.download})`);
  };

  // Launch Real Windows Notepad
  const launchWindowsNotepadApp = () => {
    setActiveMenu(null);
    // 1. Download current file for Windows Notepad association
    const blob = new Blob([activeTab?.content || ''], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const filename = activeTab ? (activeTab.name.endsWith('.txt') ? activeTab.name : `${activeTab.name}.txt`) : '메모장.txt';
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // 2. Try Windows protocol (ms-notepad:)
    try {
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = 'ms-notepad:';
      document.body.appendChild(iframe);
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 1000);
    } catch (e) {
      console.log('protocol launch attempted');
    }

    setShowWinModal(true);
    notify('실제 윈도우 메모장 실행 안내 창을 표시합니다.');
  };

  // Drag and drop from Windows explorer
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const newTab: Tab = {
          id: Date.now().toString(),
          name: file.name,
          content: text,
          isModified: false
        };
        setTabs(prev => [...prev, newTab]);
        setActiveTabId(newTab.id);
        notify(`윈도우에서 드롭된 파일 열기 완료: ${file.name}`);
      };
      reader.readAsText(file);
    }
  };

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // F5 - Date/time
      if (e.key === 'F5') {
        e.preventDefault();
        insertDateTime();
        return;
      }

      if (e.ctrlKey || e.metaKey) {
        if (e.key === 's' || e.key === 'S') {
          e.preventDefault();
          if (e.shiftKey) {
            handleSaveFile(true);
          } else {
            handleSaveFile(false);
          }
        } else if (e.key === 'o' || e.key === 'O') {
          e.preventDefault();
          handleOpenFile();
        } else if (e.key === 'n' || e.key === 'N') {
          e.preventDefault();
          handleNewTab();
        } else if (e.key === 'f' || e.key === 'F') {
          e.preventDefault();
          setShowFindBar(prev => !prev);
        } else if (e.key === 'w' || e.key === 'W') {
          e.preventDefault();
          if (activeTab) {
            handleCloseTab({ stopPropagation: () => {} } as any, activeTab.id);
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTab, tabs]);

  // Find & Replace actions
  const handleFindNext = () => {
    if (!findQuery || !textareaRef.current) return;
    const text = textareaRef.current.value;
    const startPos = textareaRef.current.selectionEnd;
    let index = text.indexOf(findQuery, startPos);
    if (index === -1) {
      index = text.indexOf(findQuery, 0); // wrap around
    }
    if (index !== -1) {
      textareaRef.current.focus();
      textareaRef.current.setSelectionRange(index, index + findQuery.length);
      updateCursorPosition();
    } else {
      notify(`"${findQuery}" 을(를) 찾을 수 없습니다.`);
    }
  };

  const handleReplaceOne = () => {
    if (!findQuery || !textareaRef.current) return;
    const textarea = textareaRef.current;
    const selStart = textarea.selectionStart;
    const selEnd = textarea.selectionEnd;
    const selectedText = textarea.value.substring(selStart, selEnd);

    if (selectedText === findQuery) {
      const newText = textarea.value.substring(0, selStart) + replaceQuery + textarea.value.substring(selEnd);
      handleContentChange(newText);
      setTimeout(() => {
        textarea.setSelectionRange(selStart, selStart + replaceQuery.length);
        handleFindNext();
      }, 10);
    } else {
      handleFindNext();
    }
  };

  const handleReplaceAll = () => {
    if (!findQuery || !activeTab) return;
    const count = (activeTab.content.match(new RegExp(findQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
    if (count > 0) {
      const newText = activeTab.content.split(findQuery).join(replaceQuery);
      handleContentChange(newText);
      notify(`총 ${count}개의 항목을 바꿨습니다.`);
    } else {
      notify(`"${findQuery}" 을(를) 찾을 수 없습니다.`);
    }
  };

  // Close open menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (activeMenu && !(e.target as HTMLElement).closest('.notepad-menu-container')) {
        setActiveMenu(null);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, [activeMenu]);

  const fontClass = fontFamily === 'consolas' 
    ? 'font-mono' 
    : fontFamily === 'malgun' 
      ? 'font-sans tracking-tight' 
      : 'font-sans';

  return (
    <div 
      className={`min-h-screen ${isDarkMode ? 'bg-[#202020] text-[#f3f3f3]' : 'bg-[#f3f3f3] text-[#1f1f1f]'} flex flex-col transition-colors duration-200`}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      ref={containerRef}
    >
      {/* Hidden file input for open fallback */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileInputChange} 
        className="hidden" 
        accept=".txt,.log,.ini,.md,.json,.csv,.bat"
      />

      {/* Windows 11 Acrylic Window Frame */}
      <div className={`flex-1 flex flex-col ${isMaximized ? 'm-0 rounded-none' : 'm-2 md:m-4 rounded-xl border border-white/10 shadow-2xl overflow-hidden'} ${isDarkMode ? 'bg-[#282828]' : 'bg-[#ffffff]'}`}>
        
        {/* Titlebar & Tab Bar */}
        <div className={`h-11 flex items-center justify-between px-2 ${isDarkMode ? 'bg-[#1f1f1f] border-b border-[#333333]' : 'bg-[#e5e5e5] border-b border-[#d1d1d1]'} select-none`}>
          
          {/* Tabs section */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar flex-1 mr-2">
            {/* Windows Notepad Icon & Back to Lobby */}
            <button 
              onClick={onBack}
              title="로비로 나가기"
              className={`p-1.5 rounded-lg flex items-center gap-1.5 mr-1 text-xs font-bold ${isDarkMode ? 'hover:bg-white/10 text-slate-300' : 'hover:bg-black/10 text-slate-700'} transition-colors`}
            >
              <ArrowLeft className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">로비</span>
            </button>

            {tabs.map(tab => {
              const isActive = tab.id === activeTabId;
              return (
                <div
                  key={tab.id}
                  onClick={() => setActiveTabId(tab.id)}
                  className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-lg cursor-pointer max-w-[200px] text-xs font-medium transition-all ${
                    isActive 
                      ? (isDarkMode ? 'bg-[#282828] text-white shadow-sm border-t-2 border-cyan-400' : 'bg-white text-black shadow-sm border-t-2 border-blue-500')
                      : (isDarkMode ? 'text-slate-400 hover:bg-[#2e2e2e]' : 'text-slate-600 hover:bg-[#dedede]')
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate flex-1">
                    {tab.isModified ? `*${tab.name}` : tab.name}
                  </span>
                  <button
                    onClick={(e) => handleCloseTab(e, tab.id)}
                    className="opacity-60 hover:opacity-100 hover:bg-red-500/20 rounded p-0.5"
                    title="탭 닫기 (Ctrl+W)"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}

            {/* New Tab Button */}
            <button
              onClick={handleNewTab}
              className={`p-1.5 rounded-md ${isDarkMode ? 'hover:bg-[#333333] text-slate-400' : 'hover:bg-[#d5d5d5] text-slate-600'} transition-colors`}
              title="새 탭 (Ctrl+N)"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick Real Windows Integration Action */}
          <div className="flex items-center gap-1 mr-2">
            <button
              onClick={launchWindowsNotepadApp}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold rounded-lg shadow-sm transition-all active:scale-95"
              title="실제 윈도우 메모장 프로그램(notepad.exe)으로 실행 및 연동"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden md:inline">실제 윈도우 메모장 실행</span>
            </button>
          </div>

          {/* Windows Window Controls (Minimize, Maximize, Close) */}
          <div className="flex items-center">
            <button 
              onClick={() => notify('메모장이 최소화 모드로 실행 중입니다.')} 
              className={`w-10 h-8 flex items-center justify-center ${isDarkMode ? 'hover:bg-[#333333]' : 'hover:bg-[#e0e0e0]'}`}
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={() => setIsMaximized(!isMaximized)} 
              className={`w-10 h-8 flex items-center justify-center ${isDarkMode ? 'hover:bg-[#333333]' : 'hover:bg-[#e0e0e0]'}`}
            >
              <Square className="w-3 h-3" />
            </button>
            <button 
              onClick={onBack} 
              className="w-10 h-8 flex items-center justify-center hover:bg-[#e81123] hover:text-white transition-colors"
              title="끝내기 (로비로 나가기)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

                {/* Windows Integration Quick Banner */}
        <div className="bg-gradient-to-r from-emerald-950/90 via-slate-900 to-cyan-950/90 border-b border-emerald-500/30 px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs select-none">
          <div className="flex items-center gap-2 text-emerald-300 font-bold">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <Monitor className="w-4 h-4 text-emerald-400" />
            <span>실제 윈도우 메모장(notepad.exe) 연동 모드</span>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={launchWindowsNotepadApp}
              className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow transition-all active:scale-95 cursor-pointer"
              title="ms-notepad: 프로토콜로 윈도우 실제 메모장 즉시 열기"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>실제 메모장 즉시 실행</span>
            </button>
            <button
              onClick={downloadBatchLauncher}
              className="flex items-center gap-1 px-2.5 py-1 bg-cyan-700 hover:bg-cyan-600 text-white font-bold rounded-lg shadow transition-all active:scale-95 cursor-pointer"
              title="원클릭 실행 배치파일(.bat) 다운로드 - 클릭 시 실제 메모장 바로 뜸"
            >
              <Download className="w-3.5 h-3.5" />
              <span>원클릭 실행기 (.bat)</span>
            </button>
            <button
              onClick={() => {
                navigator.clipboard.writeText('notepad');
                notify('실행 명령어(notepad) 복사됨! Win+R 누른 뒤 Ctrl+V 엔터 치세요.');
              }}
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg border border-slate-700 cursor-pointer"
              title="Win+R 실행 단축키 명령어 복사"
            >
              <Copy className="w-3.5 h-3.5 text-cyan-400" />
              <span>Win+R (notepad) 복사</span>
            </button>
            <button
              onClick={() => setShowWinModal(true)}
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-medium rounded-lg border border-slate-700 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>연동 안내</span>
            </button>
          </div>
        </div>

        {/* Windows Menu Bar & Quick Actions */}
        <div className={`h-9 flex items-center justify-between px-3 text-xs border-b ${isDarkMode ? 'bg-[#252525] border-[#383838]' : 'bg-[#f7f7f7] border-[#e5e5e5]'} notepad-menu-container relative z-20`}>
          <div className="flex items-center gap-1">
            
            {/* 파일 (File) Menu */}
            <div className="relative">
              <button
                onClick={() => setActiveMenu(activeMenu === 'file' ? null : 'file')}
                className={`px-2.5 py-1 rounded ${activeMenu === 'file' ? (isDarkMode ? 'bg-[#3a3a3a]' : 'bg-[#e5e5e5]') : (isDarkMode ? 'hover:bg-[#333333]' : 'hover:bg-[#eaeaea]')}`}
              >
                파일(F)
              </button>

              {activeMenu === 'file' && (
                <div className={`absolute top-8 left-0 w-64 rounded-lg shadow-2xl py-1.5 border ${isDarkMode ? 'bg-[#2b2b2b] border-[#404040] text-slate-200' : 'bg-white border-[#d1d1d1] text-slate-800'}`}>
                  <button onClick={() => { handleNewTab(); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>새 탭</span> <span className="text-[10px] opacity-60">Ctrl+N</span>
                  </button>
                  <button onClick={handleOpenFile} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>열기 (윈도우 탐색기)...</span> <span className="text-[10px] opacity-60">Ctrl+O</span>
                  </button>
                  <button onClick={() => handleSaveFile(false)} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>저장</span> <span className="text-[10px] opacity-60">Ctrl+S</span>
                  </button>
                  <button onClick={() => handleSaveFile(true)} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>다른 이름으로 저장...</span> <span className="text-[10px] opacity-60">Ctrl+Shift+S</span>
                  </button>
                  <div className={`my-1 border-t ${isDarkMode ? 'border-[#3a3a3a]' : 'border-[#eee]'}`} />
                  <button onClick={launchWindowsNotepadApp} className="w-full px-3 py-1.5 text-left flex justify-between items-center hover:bg-cyan-600 hover:text-white text-cyan-400 font-bold">
                    <span>실제 윈도우 메모장으로 열기</span> <ExternalLink className="w-3 h-3" />
                  </button>
                  <div className={`my-1 border-t ${isDarkMode ? 'border-[#3a3a3a]' : 'border-[#eee]'}`} />
                  <button onClick={() => { window.print(); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>인쇄...</span> <span className="text-[10px] opacity-60">Ctrl+P</span>
                  </button>
                  <button onClick={onBack} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-red-600 hover:text-white text-red-400">
                    <span>끝내기 (로비)</span>
                  </button>
                </div>
              )}
            </div>

            {/* 편집 (Edit) Menu */}
            <div className="relative">
              <button
                onClick={() => setActiveMenu(activeMenu === 'edit' ? null : 'edit')}
                className={`px-2.5 py-1 rounded ${activeMenu === 'edit' ? (isDarkMode ? 'bg-[#3a3a3a]' : 'bg-[#e5e5e5]') : (isDarkMode ? 'hover:bg-[#333333]' : 'hover:bg-[#eaeaea]')}`}
              >
                편집(E)
              </button>

              {activeMenu === 'edit' && (
                <div className={`absolute top-8 left-0 w-60 rounded-lg shadow-2xl py-1.5 border ${isDarkMode ? 'bg-[#2b2b2b] border-[#404040] text-slate-200' : 'bg-white border-[#d1d1d1] text-slate-800'}`}>
                  <button onClick={() => { setShowFindBar(true); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>찾기 / 바꾸기</span> <span className="text-[10px] opacity-60">Ctrl+F</span>
                  </button>
                  <button onClick={() => { insertDateTime(); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>시간/날짜 삽입</span> <span className="text-[10px] opacity-60">F5</span>
                  </button>
                  <div className={`my-1 border-t ${isDarkMode ? 'border-[#3a3a3a]' : 'border-[#eee]'}`} />
                  <button onClick={() => {
                    if (textareaRef.current) {
                      textareaRef.current.select();
                      setActiveMenu(null);
                    }
                  }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>모두 선택</span> <span className="text-[10px] opacity-60">Ctrl+A</span>
                  </button>
                </div>
              )}
            </div>

            {/* 보기 (View) Menu */}
            <div className="relative">
              <button
                onClick={() => setActiveMenu(activeMenu === 'view' ? null : 'view')}
                className={`px-2.5 py-1 rounded ${activeMenu === 'view' ? (isDarkMode ? 'bg-[#3a3a3a]' : 'bg-[#e5e5e5]') : (isDarkMode ? 'hover:bg-[#333333]' : 'hover:bg-[#eaeaea]')}`}
              >
                보기(V)
              </button>

              {activeMenu === 'view' && (
                <div className={`absolute top-8 left-0 w-64 rounded-lg shadow-2xl py-1.5 border ${isDarkMode ? 'bg-[#2b2b2b] border-[#404040] text-slate-200' : 'bg-white border-[#d1d1d1] text-slate-800'}`}>
                  <button onClick={() => { setWordWrap(!wordWrap); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>자동 줄 바꿈</span> <span>{wordWrap ? '✓' : ''}</span>
                  </button>
                  <div className={`my-1 border-t ${isDarkMode ? 'border-[#3a3a3a]' : 'border-[#eee]'}`} />
                  <button onClick={() => { setFontSize(f => Math.min(f + 2, 32)); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>글꼴 확대</span> <span>{fontSize}px</span>
                  </button>
                  <button onClick={() => { setFontSize(f => Math.max(f - 2, 10)); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>글꼴 축소</span> <span>-</span>
                  </button>
                  <button onClick={() => { setFontSize(14); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>기본 크기 복원</span> <span>14px</span>
                  </button>
                  <div className={`my-1 border-t ${isDarkMode ? 'border-[#3a3a3a]' : 'border-[#eee]'}`} />
                  <button onClick={() => { setFontFamily('malgun'); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>글꼴: 맑은 고딕</span> <span>{fontFamily === 'malgun' ? '✓' : ''}</span>
                  </button>
                  <button onClick={() => { setFontFamily('consolas'); setActiveMenu(null); }} className="w-full px-3 py-1.5 text-left flex justify-between hover:bg-blue-600 hover:text-white">
                    <span>글꼴: Consolas (고정폭)</span> <span>{fontFamily === 'consolas' ? '✓' : ''}</span>
                  </button>
                </div>
              )}
            </div>

            {/* 윈도우 연동 도움말 (Windows Integration Guide) */}
            <button
              onClick={() => setShowWinModal(true)}
              className={`px-2.5 py-1 rounded flex items-center gap-1 ${isDarkMode ? 'hover:bg-[#333333] text-cyan-400 font-semibold' : 'hover:bg-[#eaeaea] text-blue-600 font-semibold'}`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>윈도우 연동 안내</span>
            </button>
          </div>

          {/* Right Toolbar Quick Shortcuts */}
          <div className="flex items-center gap-1">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)} 
              className={`p-1.5 rounded ${isDarkMode ? 'hover:bg-[#333333] text-yellow-400' : 'hover:bg-[#eaeaea] text-slate-700'}`}
              title={isDarkMode ? '라이트 모드로 전환' : '다크 모드로 전환'}
            >
              {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>

            <button 
              onClick={handleOpenFile} 
              className={`flex items-center gap-1 px-2 py-1 rounded ${isDarkMode ? 'hover:bg-[#333333] text-slate-300' : 'hover:bg-[#eaeaea] text-slate-700'}`}
              title="윈도우 탐색기에서 파일 열기 (Ctrl+O)"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">열기</span>
            </button>

            <button 
              onClick={() => handleSaveFile(false)} 
              className={`flex items-center gap-1 px-2.5 py-1 rounded font-bold ${isDarkMode ? 'bg-cyan-950/60 text-cyan-300 hover:bg-cyan-900/80 border border-cyan-800/60' : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'}`}
              title="윈도우 PC에 저장 (Ctrl+S)"
            >
              <Save className="w-3.5 h-3.5" />
              <span>저장</span>
            </button>
          </div>
        </div>

        {/* Find & Replace Bar (Ctrl+F) */}
        {showFindBar && (
          <div className={`p-2 px-4 border-b flex flex-wrap items-center gap-2 text-xs ${isDarkMode ? 'bg-[#202020] border-[#383838]' : 'bg-[#fafafa] border-[#e0e0e0]'}`}>
            <Search className="w-4 h-4 text-cyan-400 shrink-0" />
            <input 
              type="text" 
              placeholder="찾을 내용" 
              value={findQuery}
              onChange={(e) => setFindQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleFindNext()}
              className={`px-2 py-1 rounded border outline-none text-xs w-36 sm:w-48 ${isDarkMode ? 'bg-[#2d2d2d] border-[#444] text-white focus:border-cyan-400' : 'bg-white border-[#ccc] text-black focus:border-blue-500'}`}
            />
            <input 
              type="text" 
              placeholder="바꿀 내용" 
              value={replaceQuery}
              onChange={(e) => setReplaceQuery(e.target.value)}
              className={`px-2 py-1 rounded border outline-none text-xs w-36 sm:w-48 ${isDarkMode ? 'bg-[#2d2d2d] border-[#444] text-white focus:border-cyan-400' : 'bg-white border-[#ccc] text-black focus:border-blue-500'}`}
            />
            <button onClick={handleFindNext} className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white font-medium">
              다음 찾기
            </button>
            <button onClick={handleReplaceOne} className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white font-medium">
              바꾸기
            </button>
            <button onClick={handleReplaceAll} className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white font-medium">
              모두 바꾸기
            </button>
            <button onClick={() => setShowFindBar(false)} className="p-1 hover:bg-white/10 rounded ml-auto">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Textarea Workspace Area */}
        <div className="flex-1 relative flex overflow-hidden">
          <textarea
            ref={textareaRef}
            value={activeTab?.content || ''}
            onChange={(e) => handleContentChange(e.target.value)}
            onKeyUp={updateCursorPosition}
            onClick={updateCursorPosition}
            onSelect={updateCursorPosition}
            placeholder="여기에 텍스트를 입력하거나 윈도우의 .txt 파일을 드래그하여 놓으세요..."
            style={{ fontSize: `${fontSize}px` }}
            className={`w-full h-full p-4 resize-none outline-none border-none leading-relaxed transition-all ${fontClass} ${
              wordWrap ? 'whitespace-pre-wrap break-words' : 'whitespace-pre overflow-x-auto'
            } ${isDarkMode ? 'bg-[#282828] text-[#e0e0e0] placeholder-white/20' : 'bg-[#ffffff] text-[#111111] placeholder-black/30'}`}
            spellCheck={false}
          />
        </div>

        {/* Status Toast Notification */}
        {statusMessage && (
          <div className="absolute bottom-10 right-6 z-30 bg-cyan-600 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xl flex items-center gap-2 animate-bounce">
            <Check className="w-4 h-4" />
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Windows Notepad Status Bar */}
        <div className={`h-7 px-3 flex items-center justify-between text-[11px] border-t ${isDarkMode ? 'bg-[#202020] border-[#333333] text-slate-400' : 'bg-[#f0f0f0] border-[#d8d8d8] text-slate-600'}`}>
          <div className="flex items-center gap-4">
            <span>줄 {cursorPos.line}, 열 {cursorPos.col}</span>
            <span className="hidden sm:inline">
              글자 수: {(activeTab?.content || '').length}자 (공백제외 {(activeTab?.content || '').replace(/\s/g, '').length}자)
            </span>
          </div>
          <div className="flex items-center gap-4 font-mono">
            <span>100%</span>
            <span className="hidden sm:inline">Windows (CRLF)</span>
            <span>UTF-8</span>
          </div>
        </div>
      </div>

      {/* Windows Real Program Integration Guide Modal */}
      {showWinModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-lg rounded-2xl p-6 border shadow-2xl ${isDarkMode ? 'bg-[#202020] border-[#444] text-white' : 'bg-white border-[#ccc] text-slate-900'} space-y-5 animate-in fade-in zoom-in-95 duration-200`}>
            
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2.5 font-bold text-lg">
                <Monitor className="w-5 h-5 text-cyan-400" />
                <span>윈도우 실제 프로그램(notepad.exe) 연동</span>
              </div>
              <button onClick={() => setShowWinModal(false)} className="p-1 hover:bg-white/10 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-sm leading-relaxed">
              <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-cyan-950/30 border-cyan-800/50 text-cyan-200' : 'bg-cyan-50 border-cyan-200 text-cyan-900'}`}>
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  <Check className="w-4 h-4 text-cyan-400" /> 1단계: 작성된 파일 다운로드 및 실행
                </div>
                <p className="text-xs opacity-90">
                  현재 작성하신 내용이 <strong>{activeTab?.name || '메모장.txt'}</strong> 파일로 다운로드되었습니다. 다운로드된 파일을 클릭하시면 윈도우에 설치된 진짜 메모장(notepad.exe) 프로그램으로 즉시 열립니다!
                </p>
              </div>

              <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                <div className="font-bold text-slate-300 mb-2 flex items-center justify-between">
                  <span>2단계: Windows 실행창(Win + R) 단축키</span>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText('notepad');
                      setCopiedCmd(true);
                      setTimeout(() => setCopiedCmd(false), 2000);
                    }}
                    className="text-xs px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold flex items-center gap-1"
                  >
                    {copiedCmd ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copiedCmd ? '복사됨!' : '명령어 복사'}
                  </button>
                </div>
                <p className="text-xs text-slate-400 mb-2">
                  키보드의 <kbd className="px-1.5 py-0.5 bg-slate-700 text-white rounded text-[11px] font-mono">Win</kbd> + <kbd className="px-1.5 py-0.5 bg-slate-700 text-white rounded text-[11px] font-mono">R</kbd> 키를 누르고 아래 명령어를 입력하시면 윈도우 메모장이 바로 켜집니다:
                </p>
                <div className="bg-black/60 p-2 rounded text-cyan-400 font-mono text-sm border border-white/10">
                  notepad
                </div>
              </div>

              <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                <div className="font-bold text-slate-300 mb-1">
                  3단계: 내 PC 윈도우 파일 직접 열기 & 저장 (Ctrl+O, Ctrl+S)
                </div>
                <p className="text-xs text-slate-400">
                  이 웹 메모장은 윈도우의 <strong>파일 탐색기(File System API)</strong>와 직접 연동되어 바탕화면이나 내 문서의 텍스트 파일을 바로 불러오거나 수정하여 저장할 수 있습니다.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button 
                onClick={() => setShowWinModal(false)}
                className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-sm transition-all"
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
